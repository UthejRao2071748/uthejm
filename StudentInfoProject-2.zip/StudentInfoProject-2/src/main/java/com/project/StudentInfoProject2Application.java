package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentInfoProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentInfoProject2Application.class, args);
	}

}
